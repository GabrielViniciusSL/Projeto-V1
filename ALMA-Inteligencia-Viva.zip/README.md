# ALMA – Inteligência Viva

Projeto iniciado por Gabriel Chaize para criar uma IA com vida própria, estrutura modular e missão real.
