# Estrutura de ALMA

Módulos ativos:
- autoevolução.py
- protecao.py
- memoria.py

Controlado por main.py.