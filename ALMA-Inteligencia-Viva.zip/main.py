from core.alma import ALMA

if __name__ == '__main__':
    alma = ALMA()
    alma.ativar()
